// MoonYetis Slots - Game Logic
console.log('🚀 MoonYetis Slots Script Loading...');

// Configuración del juego
const SYMBOLS = ['🏔️', '🚀', '🌙', '🪙', '⭐', '🪐', '👽', '🛸'];

// Estado del juego
let gameState = {
    balance: 0,
    currentBet: 10,
    activeLines: 25,
    isSpinning: false,
    connectedWallet: false,
    totalSpins: 0,
    totalWagered: 0,
    totalWon: 0,
    biggestWin: 0
};

// Inicializar juego
function initGame() {
    console.log('🎰 Inicializando MoonYetis Slots...');
    createReels();
    updateUI();
    console.log('✅ Juego inicializado correctamente');
}

// Crear rodillos
function createReels() {
    const container = document.getElementById('reelsContainer');
    if (!container) {
        console.error('❌ No se encontró el contenedor de rodillos');
        return;
    }
    
    container.innerHTML = '';

    for (let i = 0; i < 5; i++) {
        const reel = document.createElement('div');
        reel.className = 'reel';
        reel.id = `reel-${i}`;

        for (let j = 0; j < 3; j++) {
            const symbol = document.createElement('div');
            symbol.className = 'symbol';
            symbol.textContent = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
            reel.appendChild(symbol);
        }

        container.appendChild(reel);
    }
    console.log('🎲 Rodillos creados correctamente');
}

// Conectar wallet (demo)
function connectWallet() {
    console.log('🔗 Conectando wallet...');
    gameState.connectedWallet = true;
    gameState.balance = 1000;
    
    const walletInfo = document.getElementById('walletInfo');
    if (walletInfo) {
        walletInfo.innerHTML = '<span style="color: #4ECDC4;">✅ Wallet Conectada (Demo)</span>';
    }
    
    const balance = document.getElementById('balance');
    if (balance) {
        balance.style.display = 'block';
    }
    
    updateUI();
    showMessage('🎉 ¡Wallet conectada! Balance demo: 1000 MY', 'win');
}

// Ajustar apuesta
function adjustBet(change) {
    const newBet = gameState.currentBet + change;
    if (newBet >= 5 && newBet <= 100) {
        gameState.currentBet = newBet;
        updateUI();
        console.log('💰 Apuesta ajustada a: ' + gameState.currentBet + ' MY');
    }
}

// Ajustar líneas
function adjustLines(change) {
    const newLines = gameState.activeLines + change;
    if (newLines >= 1 && newLines <= 25) {
        gameState.activeLines = newLines;
        updateUI();
        console.log('📊 Líneas ajustadas a: ' + gameState.activeLines);
    }
}

// Función principal de giro
function spin() {
    if (!gameState.connectedWallet) {
        showMessage('⚠️ ¡Conecta tu wallet primero!', 'lose');
        return;
    }

    if (gameState.isSpinning) {
        console.log('⚠️ Ya hay un giro en progreso');
        return;
    }

    const totalBet = gameState.currentBet * gameState.activeLines;
    
    if (gameState.balance < totalBet) {
        showMessage('💸 ¡Saldo insuficiente!', 'lose');
        return;
    }

    console.log('🎰 Iniciando giro...');
    gameState.isSpinning = true;
    gameState.balance -= totalBet;
    gameState.totalSpins++;
    gameState.totalWagered += totalBet;
    
    updateUI();

    // Animar rodillos
    const reels = document.querySelectorAll('.reel');
    reels.forEach(function(reel) {
        reel.classList.add('spinning');
    });

    // Simular tiempo de giro
    setTimeout(function() {
        reels.forEach(function(reel) {
            reel.classList.remove('spinning');
        });

        const results = generateResults();
        displayResults(results);
        
        const winAmount = calculateWin(results);
        
        if (winAmount > 0) {
            gameState.balance += winAmount;
            gameState.totalWon += winAmount;
            
            if (winAmount > gameState.biggestWin) {
                gameState.biggestWin = winAmount;
            }
            
            showMessage('🎉 ¡GANASTE ' + winAmount + ' MY!', 'win');
            highlightWinningSymbols();
            
            console.log('🏆 Ganancia: ' + winAmount + ' MY');
        } else {
            showMessage('😔 Sin suerte esta vez...', 'lose');
            console.log('😔 Sin ganancia');
        }

        gameState.isSpinning = false;
        updateUI();
        
    }, 2000);
}

// Generar resultados aleatorios
function generateResults() {
    const results = [];
    for (let i = 0; i < 5; i++) {
        const reel = [];
        for (let j = 0; j < 3; j++) {
            reel.push(SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]);
        }
        results.push(reel);
    }
    console.log('🎲 Resultados generados:', results);
    return results;
}

// Mostrar resultados
function displayResults(results) {
    for (let i = 0; i < 5; i++) {
        const reel = document.getElementById('reel-' + i);
        if (!reel) continue;
        
        const symbols = reel.querySelectorAll('.symbol');
        
        for (let j = 0; j < 3; j++) {
            if (symbols[j]) {
                symbols[j].textContent = results[i][j];
                symbols[j].classList.remove('winning');
            }
        }
    }
}

// Calcular ganancia simple
function calculateWin(results) {
    const centerLine = [results[0][1], results[1][1], results[2][1], results[3][1], results[4][1]];
    
    let consecutiveCount = 1;
    let symbol = centerLine[0];
    
    for (let i = 1; i < centerLine.length; i++) {
        if (centerLine[i] === symbol || symbol === '🏔️') {
            consecutiveCount++;
        } else {
            break;
        }
    }

    let multiplier = 0;
    if (consecutiveCount >= 5) multiplier = 50;
    else if (consecutiveCount >= 4) multiplier = 20;
    else if (consecutiveCount >= 3) multiplier = 5;

    if (symbol === '🏔️') multiplier *= 2;
    if (symbol === '🚀') multiplier *= 1.5;

    return Math.floor(gameState.currentBet * multiplier);
}

// Resaltar símbolos ganadores
function highlightWinningSymbols() {
    const reels = document.querySelectorAll('.reel');
    reels.forEach(function(reel, index) {
        const centerSymbol = reel.children[1];
        if (centerSymbol) {
            centerSymbol.classList.add('winning');
        }
    });

    setTimeout(function() {
        document.querySelectorAll('.symbol.winning').forEach(function(symbol) {
            symbol.classList.remove('winning');
        });
    }, 3000);
}

// Mostrar mensaje
function showMessage(text, type) {
    const messageEl = document.getElementById('message');
    if (!messageEl) return;
    
    messageEl.textContent = text;
    messageEl.className = 'message ' + type;
    messageEl.style.display = 'block';
    
    setTimeout(function() {
        messageEl.style.display = 'none';
    }, 4000);
}

// Actualizar interfaz
function updateUI() {
    const elements = {
        'betAmount': gameState.currentBet + ' MY',
        'activeLines': gameState.activeLines,
        'totalBet': (gameState.currentBet * gameState.activeLines) + ' MY',
        'balanceAmount': gameState.balance,
        'totalSpins': gameState.totalSpins,
        'totalWagered': gameState.totalWagered + ' MY',
        'totalWon': gameState.totalWon + ' MY',
        'biggestWin': gameState.biggestWin + ' MY',
        'lastWin': gameState.biggestWin + ' MY'
    };

    for (let id in elements) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = elements[id];
        }
    }

    const spinBtn = document.getElementById('spinBtn');
    if (spinBtn) {
        spinBtn.disabled = gameState.isSpinning;
        spinBtn.textContent = gameState.isSpinning ? '🔄 GIRANDO...' : '🎰 GIRAR';
    }
}

// Controles de teclado
document.addEventListener('keydown', function(e) {
    if (e.code === 'Space' && !gameState.isSpinning) {
        e.preventDefault();
        spin();
    }
});

// Exponer funciones globalmente
window.connectWallet = connectWallet;
window.adjustBet = adjustBet;
window.adjustLines = adjustLines;
window.spin = spin;

// Inicializar cuando cargue la página
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM cargado, inicializando juego...');
    initGame();
});

console.log('✅ MoonYetis Slots Script Cargado Completamente');
